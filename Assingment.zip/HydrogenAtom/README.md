# HydrogenAtomShooting
Solution of Hydrogen atom Schrodinger's equation usinf Shooting method 
# Guide
